FlappyBird
==========

Java Replica of the original Flappy Bird for mobile game created by Dong Nguyen.



![Alt text](https://raw.githubusercontent.com/MicahAndWill/FlappyBird/master/screenShots/screenshot1.png "FlappyBird Screen Shot")


![Alt text](https://raw.githubusercontent.com/MicahAndWill/FlappyBird/master/screenShots/screenShot3.png "FlappyBird Screen Shot")

![Alt text](https://raw.githubusercontent.com/MicahAndWill/FlappyBird/master/screenShots/screenShot2.png "FlappyBird Screen Shot")
# Original-Flappy-Bird-in-Java
